const Product = require('../models/Product');
exports.createProduct = async (req, res) => {
  // Create new product
  let product = new Product(req.body);

  // Save product
  await product.save();
  
  // Send response
  res.send(product);
};

exports.updateProduct = async (req, res) => {
  // Find and update product
  let product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!product) return res.status(404).send('The product with the given ID was not found.');

  // Send response
  res.send(product);
};

exports.deleteProduct = async (req, res) => {
  // Find and delete product
  let product = await Product.findByIdAndRemove(req.params.id);
  if (!product) return res.status(404).send('The product with the given ID was not found.');

  // Send response
  res.send(product);
};

exports.getProduct = async (req, res) => {
  // Find product
  let product = await Product.findById(req.params.id);
  if (!product) return res.status(404).send('The product with the given ID was not found.');

  // Send response
  res.send(product);
};

exports.getProducts = async (req, res) => {
  // Get all products
  const products = await Product.find();

  // Send response
  res.send(products);
};