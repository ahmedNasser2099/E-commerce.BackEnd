const express = require('express');
const router = express.Router();
const usersController = require('../controllers/usersController');
const auth = require('../middleware/auth');

router.post('/register', usersController.registerUser);
router.post('/login', usersController.loginUser);
router.delete('/:id', auth, usersController.deleteUser);
router.get('/users', usersController.isAdmin, usersController.getUsers);
router.delete('/users/:id', usersController.isAdmin, usersController.deleteUser);

module.exports = router;