const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  
  
  id:Number,
  firstName: String,
  lastName: String,
  userName: {
    type: String,
    validate: {
      validator: function(v) {
        return /^[A-Za-z]+$/.test(v);
      },
      message: props => `${props.value} should only contain letters!`
    },
    required: [true, 'User name required']
  },
  email: String,
  password: String,
  phoneNumber: Number,
  address: String,
  cart: Array,
  isAdmin: { type: Boolean }
});

module.exports = mongoose.model('User', UserSchema);